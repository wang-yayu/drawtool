.. calculator_sphinx documentation master file, created by
   sphinx-quickstart on Wed Aug 23 19:25:33 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

欢迎来到calculator说明文档!
=============================================

.. toctree::
   :maxdepth: 10
   :caption: Contents:

   modules.rst


索引和目录
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
