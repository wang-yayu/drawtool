

def center_window(w, h):
    """set the size of the window

    Args:
        w (interger): the width of the window
        h (interger): the height of the window
    """    
    app.winfo_screenwidth()
    app.winfo_screenheight()
    app.geometry('%dx%d' % (w, h))


def drawCurve():
    """set the choice of "铅笔" to 1
    """ 
    what.set(1)

def drawLine():
    """set the choice of "直线" to 2
    """  
    what.set(2)

def drawRectangle():
    """set the choice of "矩形" to 3
    """ 
    what.set(3)

def drawCircle():
    """set the choice of "圆形" to 6
    """
    what.set(6)

def drawText():
    """set the choice of "文本" to 4

    Notes:
       drawText函数:要求用户输入文本、字号(字号默认值为20)
    """ 
    global text, size
    text = tkinter.simpledialog.askstring(title='输入文本', prompt='')
    if text is not None:
        size = tkinter.simpledialog.askinteger('输入字号', prompt='', initialvalue=20)
        if size is None:
            size = "20"
    what.set(4)

def onErase():
    """set the choice of "橡皮擦" to 5
    """
    what.set(5)

