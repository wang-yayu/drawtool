of\_Background\_Functions module
================================

.. automodule:: of_Background_Functions
   :members:
   :undoc-members:
   :show-inheritance:
